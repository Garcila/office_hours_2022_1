import Croc from "./Croc";
import BiteCounter from "./BiteCounter";

const App = () => {
	return (
		<div
			style={{
				height: "100vh",
				textAlign: "center",
				backgroundColor: "aqua",
				padding: "2rem",
				color: "white",
				fontSize: "3rem",
			}}
			className='container'
		>
			<Croc name='🐸' />
			<BiteCounter step={1} />
		</div>
	);
};

export default App;
