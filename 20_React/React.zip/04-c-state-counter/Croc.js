// on line function that takes props from App and renders an h1 tag
const Croc = props => <h1 className='croc'>{props.name}</h1>;

export default Croc;
