import { useState } from "react";

const BiteCounter = ({ step }) => {
	/* create state for the ClapCounter Component
      Destructured elements of useState.  
      [getterSomething, setterSomething] = useState(something) 
    */
	const [bites, setBites] = useState(0);
	const img = "🐊";

	// Handler to increase the number of claps by 1
	const handleClick = () => {
		setBites(bites + step);
	};

	// Function that adda a div when there are no bites
	const noBites = bites === 0 && (
		<div style={{ fontSize: "1.5rem", padding: "2rem" }}>
			🐝 the first to 🐊
		</div>
	);

	return (
		<div>
			<button
				type='button'
				// styling within JS requires to use cammelCase
				style={{
					cursor: "pointer",
					fontSize: "4rem",
					borderRadius: "25px",
					padding: "1rem",
					backgroundColor: "orangered",
					color: "white",
				}}
				// define what function will be invoqued when the button is clicked
				onClick={handleClick}
			>
				{/* Display the requested variable, state and conditional content */}
				{img} {bites} {img}
				{noBites}
			</button>
		</div>
	);
};
export default BiteCounter;
