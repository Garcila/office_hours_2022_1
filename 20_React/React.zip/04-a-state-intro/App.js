import { useState } from "react";

const App = () => {
	// Use the useState hook 🪝 and destructure the two items in the useState array
	// the first one is the value of the state (0 in this case) and the second a setter
	// function to update that value in the application
	const [bites, setBites] = useState(0);

	return (
		<div>
			{/* onClick call setBites to update the counter */}
			<button type='button' onClick={() => setBites(bites + 1)}>
				Bites : {bites}
			</button>
		</div>
	);
};

export default App;
