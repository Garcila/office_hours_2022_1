import { Header } from "./Header";
import { Body } from "./Body.js";
import { Footer } from "./Footer.js";

function App() {
	return (
		<div>
			{/* This is a comment in JSX */}
			{/* We are importing the three components and redering them in App */}
			<Header />
			<Body />
			<Footer />
		</div>
	);
}

export default App;
