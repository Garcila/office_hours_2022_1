import React from "react";

export const Footer = props => {
	return <footer>The end</footer>;
};
