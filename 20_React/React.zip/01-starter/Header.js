import React from "react";

export const Header = props => {
	return <h1>Title Title</h1>;
};
