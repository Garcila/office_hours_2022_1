import React from "react";

export const Body = props => {
	console.log(props);
	return (
		<main>
			<p>Something something</p>
		</main>
	);
};
