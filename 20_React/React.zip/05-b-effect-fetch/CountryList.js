import React from "react";

const Countrylist = ({ countries }) => {
	return (
		<ul>
			{countries.map(country => (
				<li key={country.name.official}>
					<span role='img' aria-label={country.flag}>
						{country.flag}
					</span>
					{country.name.official}
				</li>
			))}
		</ul>
	);
};

export default Countrylist;
