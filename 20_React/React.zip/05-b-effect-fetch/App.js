import { useState, useEffect } from "react";
import Countrylist from "./CountryList";
import "./countries.css";

const App = () => {
	const [light, setLight] = useState("🔆");
	const [countries, setCountries] = useState([]);

	// useEffect takes two arguments
	// 1. A function
	useEffect(() => {
		fetch(`https://restcountries.com/v3.1/all`)
			.then(data => data.json())
			.then(countryData => {
				console.log(countryData);
				setCountries(countryData);
			});
		// 2. an Array of changes to look for.  If empty it will only run when the
		// component is mounted, if none, it will run everytime the state changes
		// passing items means that it will run everytime that piece of state changes
	}, []);

	return (
		<div className='container'>
			<button
				onClick={() => (light === "🔆" ? setLight("🌙") : setLight("🔆"))}
			>
				{light}
			</button>
			<div className='list'>
				<Countrylist countries={countries} />
			</div>
		</div>
	);
};

export default App;
