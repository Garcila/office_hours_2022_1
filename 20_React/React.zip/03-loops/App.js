import { Header } from "./Header";
import { Body } from "./Body.js";
import "./index.css";

// We have an object of employees.  It will provide the data to populate the page
const employees = [
	{
		name: "B. Ohoo",
		badge: "👻",
		id: "00000",
		department: "Lost and Found",
	},
	{
		name: "K. Slim",
		badge: "💀",
		id: "rrrrrr",
		department: "Legal",
	},
	{
		name: "B. Ozone",
		badge: "🤡",
		id: "123456",
		department: "Horror",
	},
	{
		name: "AL Fonz",
		badge: "👽",
		id: "888888",
		department: "Accounting",
	},
	{
		name: "OG Invader",
		badge: "👾",
		id: "968896",
		department: "Management",
	},
	{
		name: "Melanie Lavander",
		badge: "🤖",
		id: "010101",
		department: "HR",
	},
	{
		name: "Patrick Luck",
		badge: "🦄",
		id: "777777",
		department: "Investment",
	},
];

function App() {
	return (
		<div className='app'>
			<Header title='Mojisink' />
			<Body employees={employees} />
		</div>
	);
}

export default App;
