import React from "react";
import "./header.css";

export const Header = props => {
	return (
		<h1>
			<span role='img' aria-label='corp'>
				🏢
			</span>
			{props.title}
		</h1>
	);
};
