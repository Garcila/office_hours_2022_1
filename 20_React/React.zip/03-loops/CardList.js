import React from "react";
import Card from "./Card";

// we import the css that we need for the page.  Letting us have multiple CSS files
import "./card.css";

const Cardlist = ({ employees }) => {
	return (
		<div className='container'>
			{/* We take the employees prop passed from App.js down to CarList */}
			{/* And loop with map over every employee to generate a Card */}
			{/* Try by not providing a key attribute to see React's reaction */}
			{employees.map(employee => (
				<Card
					key={employee.id}
					id={employee.id}
					name={employee.name}
					badge={employee.badge}
					department={employee.department}
				/>
			))}
		</div>
	);
};

export default Cardlist;
