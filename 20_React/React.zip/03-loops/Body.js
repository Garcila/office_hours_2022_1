import React from "react";
import CardList from "./CardList";

export const Body = ({ employees }) => {
	return (
		<main>
			<CardList employees={employees} />
		</main>
	);
};
