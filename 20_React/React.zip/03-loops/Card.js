import React from "react";
import "./card.css";

const Card = ({ name, badge, id, department }) => {
	return (
		<div className='card draw-border '>
			<span className='card__image' role='img' aria-label='name'>
				{badge}
			</span>
			<h2>{name}</h2>
			<p>Employee ID: {id}</p>
			<p>{department}</p>
		</div>
	);
};

export default Card;
