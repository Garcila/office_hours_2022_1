import { useState } from "react";

const App = () => {
	const [name, setName] = useState("");

	const handleChange = event => setName(event.target.value);

	return (
		<div>
			<form>
				{/* in JSC we can not use for for the label, instead use htmFor */}
				<label htmlFor='name'>Name</label>
				<input
					value={name}
					name='name'
					placeholder='name'
					onChange={handleChange}
					id='name'
				/>
			</form>
			{name ? <div>Hello {name}</div> : "Please enter your name"}
		</div>
	);
};

export default App;
