import React from "react";

{
	/* Header receives the props object with all the props we passed from App */
}
export const Header = props => {
	return (
		<div>
			<h1>
				{/* we interpolate elements from props in our JSX */}
				<span>{props.emoji}</span>
				{props.title}
			</h1>
			<p>{props.subtitle}</p>
		</div>
	);
};
