import { Header } from "./Header";
import { Card } from "./Card.js";

const cardInfo = {
	image: "https://picsum.photos/200/300",
	title: "random picsum",
	author: "Idonese Whosit",
	year: "2021",
};

function App() {
	return (
		<div>
			<Header
			    {/* We are passing different props to the Header Component */}
				emoji='🏜'
				title='Vastness'
				subtitle='Not empty, but full of not much'
			/>
			{/* to the Card component we are passin the whole cardInfo object as info */}
			<Card info={cardInfo} />
		</div>
	);
}

export default App;
