import React from "react";

export const Card = props => {
	const { image, title, author, year } = props.info;
	return (
		<div>
			<img src={image} alt={title} />
			<h2>{title}</h2>
			<p>{author}</p>
			<p>{year}</p>
		</div>
	);
};
