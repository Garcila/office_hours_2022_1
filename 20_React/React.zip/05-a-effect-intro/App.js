import { useState, useEffect } from "react";

const App = () => {
	const [name, setName] = useState("Pepito");

	// useEffect takes two arguments
	// 1. A function
	useEffect(() => {
		document.title = `You selected ${name}`;
		// 2. an Array of changes to look for.  If empty it will only run when the
		// component is mounted, if none, it will run everytime the state changes
		// passing items means that it will run everytime that piece of state changes
	}, []);
	return (
		<div>
			<button
				onClick={() =>
					name === "Pepito 👨" ? setName("Pepita 👩") : setName("Pepito 👨")
				}
			>
				{name}
			</button>
		</div>
	);
};

export default App;
